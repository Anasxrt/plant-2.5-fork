<?php
/**
 * Handle CSS output for padding control.
 *
 * @package Kirki
 * @subpackage Controls
 * @since 1.0.0
 */

namespace Kirki\Field\CSS;

/**
 * Output overrides.
 */
class Padding extends Margin {

	/**
	 * The field type.
	 *
	 * @since 1.0
	 * @access public
	 * @var string
	 */
	protected $type = 'kirki-padding';

}
